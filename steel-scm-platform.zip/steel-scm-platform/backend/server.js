import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { connectDB } from "./config/db.js";

import ordersRoutes from "./routes/orders.js";
import inventoryRoutes from "./routes/inventory.js";
import suppliersRoutes from "./routes/suppliers.js";
import shipmentsRoutes from "./routes/shipments.js";
import forecastingRoutes from "./routes/forecasting.js";
import erpRoutes from "./routes/erp.js";

dotenv.config();

const app = express();

app.use(cors());          // allows the frontend (running on a different port/file) to call this API
app.use(express.json());  // lets the server read JSON request bodies

// Health check - useful to confirm the server is up
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", service: "SteelFlow SCM API" });
});

app.use("/api/orders", ordersRoutes);
app.use("/api/inventory", inventoryRoutes);
app.use("/api/suppliers", suppliersRoutes);
app.use("/api/shipments", shipmentsRoutes);
app.use("/api/forecasting", forecastingRoutes);
app.use("/api/erp", erpRoutes);

const PORT = process.env.PORT || 5000;

connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`[SteelFlow] Server running at http://localhost:${PORT}`);
    console.log(`[SteelFlow] Try it: http://localhost:${PORT}/api/health`);
  });
});
