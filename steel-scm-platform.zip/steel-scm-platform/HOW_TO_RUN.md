# HOW TO RUN — SteelFlow SCM Platform

This guide assumes you have **never used a terminal or written code before**.
Follow it top to bottom, in order, and don't skip steps. It will take about
20–30 minutes the first time.

---

## What you're running

Two separate pieces that talk to each other over the internet-style protocol
your browser already uses:

- **`backend/`** — a small server that stores data (orders, inventory,
  suppliers, shipments) and runs the forecasting/optimization/risk-scoring
  logic. It exposes that data as a set of URLs (an "API").
- **`frontend/`** — a single web page (`index.html`) that asks the backend
  for data via those URLs and displays it as a dashboard.

Think of the backend as the kitchen and the frontend as the dining room menu
— the frontend just displays whatever the backend hands it.

---

## Step 1 — Install Node.js

Node.js is the program that runs the backend server on your computer.

1. Go to **https://nodejs.org**
2. Download the button labeled **LTS** (Long Term Support) — this is the
   stable version.
3. Run the installer, click Next through all the default options.
4. To confirm it worked, open a terminal:
   - **Windows**: press the Windows key, type `cmd`, press Enter.
   - **Mac**: press Cmd+Space, type `terminal`, press Enter.
5. Type this and press Enter:
   ```
   node -v
   ```
   You should see something like `v20.11.0`. If you see an error, restart
   your computer and try again — Node wasn't fully installed yet.

---

## Step 2 — Create a free database (MongoDB Atlas)

The backend needs a database to store orders, inventory, suppliers, and
shipments. The easiest way to get one with no installation is a free cloud
database called MongoDB Atlas.

1. Go to **https://www.mongodb.com/cloud/atlas/register** and create a free
   account.
2. When asked to create a cluster, choose the **free/shared (M0)** tier.
3. Once the cluster is created, click **"Connect"** → **"Drivers"**.
4. Copy the connection string it shows you. It looks like:
   ```
   mongodb+srv://username:<password>@cluster0.xxxxx.mongodb.net/
   ```
5. Under **Database Access**, make sure you've set a database username and
   password (Atlas will prompt you to create one during setup). Replace
   `<password>` in the connection string with that real password.
6. Under **Network Access**, click **"Add IP Address"** → **"Allow access
   from anywhere"** (fine for this demo/prototype — you'd lock this down for
   a real production system).

Keep this connection string handy — you'll paste it in Step 4.

---

## Step 3 — Open the project folder

1. Unzip the `steel-scm-platform` folder you downloaded, somewhere easy to
   find, like your Desktop.
2. You should see two folders inside: `backend` and `frontend`, plus this
   file.

---

## Step 4 — Set up the backend

1. Open your terminal (same as Step 1).

2. Navigate into the backend folder. Type `cd ` (with a space after it),
   then drag the `backend` folder from your file explorer into the terminal
   window — it will auto-fill the path. Press Enter. Example:
   ```
   cd /Users/yourname/Desktop/steel-scm-platform/backend
   ```

3. Install the backend's dependencies (the code libraries it needs to run):
   ```
   npm install
   ```
   This will take a minute or two. You'll see a progress bar and some text
   scroll by — that's normal.

4. Create your settings file:
   - Find the file named `.env.example` inside the `backend` folder.
   - Make a copy of it in the same folder, and rename the copy to `.env`
     (just `.env`, nothing before the dot).
   - Open `.env` in any text editor (Notepad, TextEdit, VS Code — anything).
   - Paste your MongoDB connection string from Step 2 into the `MONGO_URI`
     line, so it looks like:
     ```
     MONGO_URI=mongodb+srv://youruser:yourpassword@cluster0.xxxxx.mongodb.net/steelflow
     ```
     (Add `/steelflow` at the end, before any `?` characters, so it creates
     a database named "steelflow".)
   - You can leave the email (SMTP) settings blank — the app will just print
     alert emails to the terminal instead of actually sending them, which is
     perfectly fine for a demo.
   - Save the file.

5. Load the sample data into your database:
   ```
   npm run seed
   ```
   You should see messages like "Seeding orders...", "Seeding inventory...",
   ending with "Done! Sample data loaded."

6. Start the backend server:
   ```
   npm start
   ```
   You should see:
   ```
   [SteelFlow] Connected to MongoDB
   [SteelFlow] Server running at http://localhost:5000
   ```
   **Leave this terminal window open** — closing it stops the server.

7. Confirm it's working: open your web browser and go to
   ```
   http://localhost:5000/api/health
   ```
   You should see: `{"status":"ok","service":"SteelFlow SCM API"}`
   That means your backend is alive and connected to the database.

---

## Step 5 — Open the frontend dashboard

1. Leave the backend terminal window running in the background.
2. Go to the `frontend` folder and double-click `index.html`.
3. It will open in your default web browser and should immediately start
   showing live data — orders, inventory, suppliers, and so on — pulled
   from your backend.

If the dashboard says **"Backend not reachable"** in the top-right badge:
- Make sure the backend terminal window (Step 4.6) is still open and shows
  no errors.
- Make sure you went to `http://localhost:5000/api/health` and saw the
  "ok" message.
- Some browsers block a local file from calling `localhost` — if this
  happens, right-click the `frontend` folder, and look for an option to
  "Open with Live Server" if you have VS Code with the Live Server
  extension, or ask a developer to run `npx serve` inside the `frontend`
  folder as a quick fix.

---

## Every time after the first setup

You don't need to repeat all the steps above. Just:

1. Open a terminal, `cd` into the `backend` folder, run `npm start`.
2. Open `frontend/index.html` in your browser.

That's it — two things to start, every time.

---

## What each part of the dashboard is showing

- **Overview** — top-level alerts pulled live from the inventory and
  supplier risk analysis.
- **Demand Forecasting** — a moving-average + trend model run against your
  seeded order history.
- **Inventory** — reorder point / safety stock calculations per item.
- **Orders** — the raw order records in the database.
- **Supplier Risk** — the weighted risk score breakdown per supplier.
- **Logistics & Routes** — the nearest-neighbor route plan and estimated
  cost/time savings per shipment.
- **ERP Sync** — a simulated connection to a system like SAP or Oracle
  (click "Run Sync Now" to see it simulate pulling data).

---

## If you want to show this to investors or the steel company

- Practice clicking through all six sections once before the meeting so you
  know what each one shows.
- If you're not on the same laptop that's running the backend, you'll need
  to either bring that laptop, or have a developer deploy the backend to a
  cloud host (e.g. Render, Railway) so it's reachable from anywhere — this
  is a quick follow-up task for a developer once you're ready to move past
  the local demo.

---

## Common errors and what they mean

| What you see | What it means | Fix |
|---|---|---|
| `Could not connect to MongoDB` | Your `.env` file's `MONGO_URI` is wrong, or your Atlas cluster isn't allowing your IP | Re-check Step 4.4 and Step 2.6 |
| `command not found: npm` | Node.js isn't installed correctly | Redo Step 1 |
| Dashboard shows "Backend not reachable" | The backend server isn't running | Check the backend terminal window is still open with no errors |
| `EADDRINUSE` when running `npm start` | Something else is already using port 5000 | Close other terminal windows running the backend, or change `PORT` in `.env` |
